/*
 * Plan.cpp
 *
 *  Created on: Dec 21, 2014
 *      Author: user
 */

#include "Plan.h"

Plan::Plan(Robot* robot) {


}

Plan::~Plan() {
	// TODO Auto-generated destructor stub
}
